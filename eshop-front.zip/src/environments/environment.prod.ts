export const environment = {
  production: true,
  apiUrl: 'http://localhost:8080/api',
  firebase: {
    apiKey: 'AIzaSyD2FjTDZVNeehEaZ-fcxUaTSMX6teR3FCE',
    authDomain: 'eshop-2c447.firebaseapp.com',
    projectId: 'eshop-2c447',
    storageBucket: 'eshop-2c447.appspot.com',
    messagingSenderId: '595290784050',
    appId: '1:595290784050:web:24d925093910f8fb78972b',
  },
};
