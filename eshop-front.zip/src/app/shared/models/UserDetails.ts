export class UserDetails {
  id: string;
  username: string;
  email: string;
  roles: string[];
  accessToken: string;
  tokenType: string;
}
