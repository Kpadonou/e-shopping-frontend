import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ShoppingCartItem } from '../shared/models/shopping-cart-item';
import { ShoppingCartService } from '../shared/services/shopping-cart.service';
import { switchMap } from 'rxjs/operators';
import { ShoppingCart } from '../shared/models/shopping-cart';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.scss'],
})
export class ShoppingCartComponent implements OnInit {
  totalItemsCount = 0;
  totalPrice = 0;
  items$: Observable<ShoppingCartItem[]>;
  constructor(private cartService: ShoppingCartService) {}

  ngOnInit(): void {
    this.cartService.getTotalItemsAndPrice().subscribe((resp) => {
      this.totalItemsCount = resp.totalItems;
      this.totalPrice = resp.totalPrice;
    });
    this.items$ = this.cartService
      .getOrCreateCart()
      .pipe(switchMap((cart) => this.cartService.getItemsOfCart(cart.id)));
  }
}
